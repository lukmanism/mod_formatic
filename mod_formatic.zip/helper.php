<?php
/**
 *
 *
 * @package   mod_formatic
 * copyright ntahla.com/ Lukman Hussein
 * @license GPL3
 */

// no direct access
defined('_JEXEC') or die;

