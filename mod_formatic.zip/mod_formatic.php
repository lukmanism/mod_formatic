<?php
/**
 *
 *
 * @package   mod_formatic
 * copyright Lukman Hussein
 * @license GPL3
 */

// no direct access
defined('_JEXEC') or die;

require JModuleHelper::getLayoutPath('mod_formatic', $params->get('layout', 'default'));

